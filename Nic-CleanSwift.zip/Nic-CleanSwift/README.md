Author: Nithi Kulasiriswatdi

To learn more about Clean Swift and the VIP cycle, read:

http://clean-swift.com/clean-swift-ios-architecture

There is a sample app available at:

https://github.com/Clean-Swift/CleanStore

To install the Clean Swift Xcode templates, run:

> make install_templates

To uninstall the Clean Swift Xcode templates, run:

> make uninstall_templates
